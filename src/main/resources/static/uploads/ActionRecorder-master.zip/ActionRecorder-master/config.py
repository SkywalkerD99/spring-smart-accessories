config = {
    "Manual_URL" : 'https://inamurajin.wixsite.com/website/post/hint-help',
    "Hint_URL": 'https://github.com/InamuraJIN/ActionRecorder/wiki',
    "BugReport_URL": 'https://inamurajin.wixsite.com/website/post/bug-report',
    "checkSource_URL": 'https://api.github.com/repos/InamuraJIN/ActionRecorder/contents/__init__.py',
    "repoSource_URL": 'https://github.com/InamuraJIN/ActionRecorder',
    "releasNotes_URL": 'https://github.com/InamuraJIN/ActionRecorder/wiki'
}
