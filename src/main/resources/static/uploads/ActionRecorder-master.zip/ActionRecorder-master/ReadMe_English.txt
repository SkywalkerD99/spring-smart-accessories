﻿product guide


■CommandRecorder
https://eachpath.booth.pm/items/1123127
The action registration function is familiar with The DCC tool!
This is a versatile add-on that the moderator thinks and programmer implements!
CommandRecorder has fuction of records and plays.
Watch the video for installation and usage!
https://youtu.be/7UtFRyxm-EU


■Post
https://satahiko.booth.pm/items/1229821
■Vessel
https://satahiko.booth.pm/items/1123123






About CommandRecorder
▪ This is a feature that has not been introduced in the video.


You can switch the display of command history.
●Standard: Normal command display
●Extend:Displays the command in detail




■Notes


●Commands stored in the command list are passed on only for the project.
After you register and save to action button, you can use it for other projects too.


●About the commands that need to be selected
For example, you can register and execute loop cuts, but you cannot specify the application location.
Commands with important selection scope and mouse position tend to be unintended behavior.


·About Application once or each
Currently, we are dealing with the execution of each application in object mode, bone editing mode and pause mode.


● If you switch between Japanese and other languages in the middle of recording, it will be down.






〇About all products
■Terms of Use


Article 1 Definitions
The meanings of the terms listed in the following items shall be as prescribed respectively in those items.
(1) The terms of use (hereinafter referred to as "the terms") apply to all people using this service (hereinafter referred to as "Service") provided by BuuGraphic (hereinafter referred to as "Producer").
(2) Secondary works
A work means that created by translating, arranging, or transforming, or dramatizing, cinematizing or others.
(3) Modified products
A work created by modifying, excising or others does not fall under the category of a secondary work.
(4) Secondary Creation
This term refers to modifications, secondary works, and other works created based on works.


Article 2 About Use
By using this Service, users comply with the Terms and Conditions. also if users use this Service, users agree to the terms and conditions of this Service.


Article 3 Prohibited matters
Use of this Service shall prohibit the following acts (including acts inducing or preparing them)
(1) Reproduction and transfer of this Service to a third party without authorization from BuuGraphic
(2) Handling and distributing the Services and the secondary works of the Services by third parties, except where individual permissions are obtained from BuuGraphics.
(3) All or part of this Service shall be incorporated for the purpose of assignment or sale to third parties.


Article 4 Disclaimer
(1) Both these Terms and Services may be updated without notice. Please check the latest version at the following URL.
https://docs.google.com/document/d/15ktxBGEo31Ya63_vtXTljndoPHmvWvJeZaw1e_b-bXs/edit
(2) The copyright of the materials provided in this service belongs to BuuGraphics.
(3) The producer shall not be responsible for any damage or trouble caused by this service.


Article 5 Response to breach of rules
(1) If any violation of this Agreement is found, we will contact the Violator of the Agreement. Malicious offenders may be charged a fee without prior notice.


Article 6 Applicable Acts, Courts of Jurisdiction, Languages, and Other
(1) This Code shall be governed by the Japanese law and the Osaka District Court shall be the exclusive jurisdiction of the first instance.
(2) This agreement is based on Japanese and is always interpreted only in Japanese.
(3) All rights other than those stated in this Service Description are reserved in BuuGraphic.


If you have any questions or comments, please contact BuuGraphics.
Twitter：https://twitter.com/BuuGraphic
Gmail：buugraphic@gmail.com