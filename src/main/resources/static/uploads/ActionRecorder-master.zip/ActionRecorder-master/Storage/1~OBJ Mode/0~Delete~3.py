bpy.ops.object.delete(use_global=False)
