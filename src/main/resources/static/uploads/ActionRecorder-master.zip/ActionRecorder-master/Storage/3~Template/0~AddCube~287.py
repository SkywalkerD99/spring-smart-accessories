bpy.ops.view3d.snap_cursor_to_selected()
bpy.ops.mesh.primitive_cube_add(size=2, location=bpy.context.scene.cursor.location)
