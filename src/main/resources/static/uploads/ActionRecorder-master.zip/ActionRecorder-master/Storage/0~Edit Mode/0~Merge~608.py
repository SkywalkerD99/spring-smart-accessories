bpy.ops.transform.resize(value=(0, 0, 0))
bpy.ops.mesh.remove_doubles()
