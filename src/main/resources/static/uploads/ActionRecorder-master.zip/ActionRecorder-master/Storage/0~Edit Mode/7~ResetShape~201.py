bpy.ops.mesh.blend_from_shape(add=False)
