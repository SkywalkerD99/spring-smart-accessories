bpy.ops.transform.resize(value=(0, 1, 1))
