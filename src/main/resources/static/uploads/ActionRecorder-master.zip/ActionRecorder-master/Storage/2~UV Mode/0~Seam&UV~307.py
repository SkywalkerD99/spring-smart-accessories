bpy.ops.mesh.mark_seam(clear=False)
bpy.ops.mesh.select_linked(delimit=set())
bpy.ops.uv.unwrap()
