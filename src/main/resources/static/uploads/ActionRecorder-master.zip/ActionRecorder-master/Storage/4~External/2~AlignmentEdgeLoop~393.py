bpy.ops.mesh.loop_multi_select(ring=False)
bpy.ops.mesh.looptools_space(influence=100, input='selected', interpolation='cubic', lock_x=False, lock_y=False, lock_z=False)
