bpy.ops.object.duplicate_move()
bpy.ops.stb.scriptbutton(btn_name="MakeBackUP")
