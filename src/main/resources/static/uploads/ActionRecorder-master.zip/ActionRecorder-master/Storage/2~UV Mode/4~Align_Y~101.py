bpy.ops.transform.resize(value=(1, 0, 1))
