bpy.ops.transform.edge_crease(value=1)
bpy.ops.mesh.mark_sharp()
