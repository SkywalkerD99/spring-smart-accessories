bpy.ops.mesh.select_nth()
bpy.ops.mesh.loop_multi_select(ring=False)
