bpy.ops.mesh.bridge_edge_loops(use_merge=True)
