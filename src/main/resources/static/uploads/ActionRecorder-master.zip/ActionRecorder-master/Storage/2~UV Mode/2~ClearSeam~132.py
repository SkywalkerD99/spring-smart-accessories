bpy.ops.mesh.mark_seam(clear=True)
bpy.ops.mesh.select_linked(delimit=set())
bpy.ops.uv.unwrap()
