# Action Recorder
Are you tirred of coding long intimidating coding task just for one-off modeling? Or may be you're not good coding at all !<br>
Introducing "ActionRecorder" !<br>

ActRec is an add-on developed to streamline your work in Blender<br>

This add-on is similar to Affinity Photo and Photoshop's "Action"<br>
This add-on has been reborn!
**Command Recorder --> Action Recorder**

This add-on is available for Free!<br>
But, It takes a lot of coffee to develop an Add-on!
[![](https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif)](https://paypal.me/InamuraJIN?locale.x=ja_JP)

The update button has been moved!<br>
:warning: Be sure to use this button<br>
<img src="https://i.imgur.com/YAJ4wqY.png" width="150px">

# Add-ons Explained

Convert complex, repetitive tasks into one click!

You have to remember is "Add" & "Play" Only!

Supported Versions: 2.83 to 2.9

Simplify complex repetitive tasks, which were difficult to do with the standard “Repeat Last”(Shift+R) function of Blender, by registering multiple actions.

You can register, edit and play back various tasks as you wish

For example, with the touch of a button, you can do routine tasks such as adding instant coffee, milk and sugar while boiling water and adding hot water!

(I've thought about it a few times, but unfortunately this add-on only allows you to register work within Blender.)
<br><br><br>



# Tutorial&Readme
🇯🇵[日本語](https://inamurajin.wixsite.com/website/post/tutorial_readme_jp)

🇺🇸[English](https://inamurajin.wixsite.com/website/post/tutorial_readme_en)
<br><br><br>




# Update

https://github.com/InamuraJIN/ActionRecorder/wiki
<br><br><br>




# Community 
Discord<br>
https://discord.gg/XTWbkFx
<br><br><br>



# Bug Reports and Requests
- Discord<br>
https://discord.gg/XTWbkFx<br><br>
- Twitter<br>
https://twitter.com/Inamura_JIN<br><br>
- GitHub<br>
https://github.com/InamuraJIN/ActionRecorder/issues<br><br>
<br><br><br><br><br><br>
thank you
